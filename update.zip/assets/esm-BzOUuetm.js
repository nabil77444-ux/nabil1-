const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Dwp64Bvl.js","assets/dist-DPQqzMSI.js"])))=>i.map(i=>d[i]);
import{a as e}from"./dist-DPQqzMSI.js";import{i as o}from"./vendor-export-T3p4jNqW.js";var _=e("Network",{web:()=>o(()=>import("./web-Dwp64Bvl.js").then(r=>new r.NetworkWeb),__vite__mapDeps([0,1]))});export{_ as Network};
