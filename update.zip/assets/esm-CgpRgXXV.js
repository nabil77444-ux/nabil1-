const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-LWQ2x0DF.js","assets/dist-DPQqzMSI.js"])))=>i.map(i=>d[i]);
import{a as r}from"./dist-DPQqzMSI.js";import{i as e}from"./vendor-export-T3p4jNqW.js";var t=r("App",{web:()=>e(()=>import("./web-LWQ2x0DF.js").then(p=>new p.AppWeb),__vite__mapDeps([0,1]))});export{t as App};
