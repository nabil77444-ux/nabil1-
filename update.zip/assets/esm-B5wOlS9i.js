const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CATvPbYs.js","assets/dist-DPQqzMSI.js"])))=>i.map(i=>d[i]);
import{a as e}from"./dist-DPQqzMSI.js";import{i as a}from"./vendor-export-T3p4jNqW.js";var t=e("Share",{web:()=>a(()=>import("./web-CATvPbYs.js").then(r=>new r.ShareWeb),__vite__mapDeps([0,1]))});export{t as Share};
